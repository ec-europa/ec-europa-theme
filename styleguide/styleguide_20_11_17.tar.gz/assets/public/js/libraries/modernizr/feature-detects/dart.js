// Dart
// By Theodoor van Donge

// https://chromiumcodereview.appspot.com/9232049/

Modernizr.addTest('dart', !!Modernizr.prefixed('startDart', navigator));
